#include <stdio.h> 
#include <conio.h>
 #include <alloc.h>
 #include <string.h> 
struct node 
{
 char word[20];
 struct list *nolink;
 struct node *link; 
}*p,*q,*r,*f; /*q is pointing to the start of the node ,  p is for traversing through the nodes,  word stores the word to be indexed,  nolink stores the link to the list of files numbers,  link stores the link to the next indexed word */

struct list
{
 int num;
 struct list *nolink;
}*a,*b,*c; /*a is pointing to the start of the node ,  b is for traversing through the nodes.  num stores the document number,  nolink stores link to the next document number*/  /*Extract module extracts a substring from the mainstring Usage extract(main_string,intermediate_string ,result_string, starting position, no of positions from the starting position */

void extract(char *s,char *t,char *d,int pos,int len)
{
 s=s+(pos-1);
 t=s+len;
 while(s!=t)
  {
   *d=*s; s++; d++;
  }
 *d='\0';
}  /*Checks whether the word is already indexed or not r is the indermediate list variable , q is the starting point */

int check(char *str)
{
   r=q;  f=r;
  while(r!=NULL)
  {
		if(strcmp(str,r->word)==0)
		 {
		   f=r;
		   return 0;
		 }
	r=r->link;
  }
  return 1;
}
 /*Appends the index to the linked list ,also used in stop word elemination module , in that case stores all the stop words in a linked list*/

void append(char *str)
{
  struct node *temp;
  if(q==NULL)
  {
   temp = (struct node *)malloc(sizeof(struct node));
   strcpy(temp->word,str);
   temp->link=NULL;
   temp->nolink=NULL;
   p=temp;
   q=p;
   f=q;
  }
  else
  {
   temp = p;
   p = (struct node *)malloc(sizeof(struct node));
   strcpy(p->word,str);
   p->link=NULL;
   p->nolink=NULL;
   temp->link=p;
   f=p;
  }
}/*To display the linked list elements or nodes*/
void display()
{
  r=q;
  if(r==NULL)
  {
 //printf("\n\nEmpty Link List.Can't Display The Data");
   getch();
  }
  while(r!=NULL)
  {
//printf("\n%s",r->word);
   r=r->link;
  }
 }  /*Appends the list of doc id to the word indexedHere input(str1) is the mainstring or the file name actually from which we extract the document id*/
 void append_list(char *str1)
 {  
struct list *temp,*temp1;
  char *str2,*str3;
  extract(str1,str2,str3,6,1);
  temp1=f->nolink;
  if(temp1==NULL)
  {
   temp = (struct list *)malloc(sizeof(struct list));
   temp->num=atoi(str3);
   temp->nolink=NULL;
   f->nolink=temp;
  }
  else
  {
   while(temp1!=NULL)
   { 
    temp=temp1;
    if(atoi(str3)==temp->num) 
    return;
    temp1=temp1->nolink;
   }
   temp1 = (struct list *)malloc(sizeof(struct list));
   temp1->num=atoi(str3);
   temp1->nolink=NULL;
   temp->nolink=temp1;
      }
 }  /*Destroys or frees the memory allocated to the linked lists*/
 void destroy()
 {  struct node *temp,*x;
  struct list *temp1,*y;x=q;
  y=a;
  if(x==NULL && c==NULL)
  {
   printf("\n\nEmpty Link List.Can't Display The Data");
   getch();
  }
  while(r!=NULL && c!=NULL)
  {
   temp=x;
   temp1=y;
   free(temp);
   free(temp1);
   y=y->nolink;
   x=x->link;
  }
temp=q=x=p=NULL;
  temp1=y=a=b=NULL;
 }  /*This module is used to refine the input file before indexing , refining refers to removing all the punctuations. Inputs are the normal file and the file to be written after refining the stop words*/ 
void refine(char *str2,char *str3) 
{
 char *str1,line[300]; 
FILE *file=fopen(str2,"r");
 FILE *file1=fopen(str3,"a"); 
if ( file != NULL )
 {
 while ( fgets ( line, sizeof line, file ) != NULL )
       {
   str1 = strtok(line, " =-#,.:!?*\")][(\n1234567890_");
   while (1)
   {
    if(str1 != NULL)
    {
     fprintf(file1," ");
     fprintf(file1,"%s",strlwr(str1));
    }
    else
    {
     break;
    }
    str1 = strtok(NULL, " =-#,.:!?*\")][(\n1234567890_");
   }
  }
 fclose(file);
 fclose(file1);
 }
 }  /*This module is for elemination of stop words , the stop words are stored in the file stop.txt. Inputs are the refined file and the file to be written after elminating the stop words */ 
void stop_ele(char *str3,char *str4) 
{
 char line[300],line1[300];
 char *str1,*str2;
 FILE *file4=fopen(str3,"r");
FILE *file5=fopen(str4,"a");
 FILE *file6=fopen("stop.txt","r");
 int x=0;
 if ( file6 != NULL )
 {
 while ( fgets ( line, sizeof line, file6 ) != NULL)
str1 = strtok(line, " ");
   while(1)
   {
    if(str1 != NULL)
    {
     append(str1);
    }
    else
    {
     break;
    }
    str1 = strtok(NULL, " ");
   }
        }
       fclose (file6);
 }
 display();
 getch(); 
if ( file4 != NULL )
 {
 while ( fgets ( line, sizeof line, file4 ) != NULL)
       {
   str1 = strtok(line, " \n");
   while(1)
   {
    if(str1 != NULL)
    {
     x=check(str1);
     if(x==1)
     {
      fprintf(file5,"%s",str1);
      fprintf(file5," ");
     }
    }
    else
    {
     break; 
   }
    str1 = strtok(NULL, " \n");
   }
  fprintf(file5,"\n");
       }
       fclose(file4);
       fclose(file5);
 }
 }  /*This module creates the inverted index in terms of linked list. The words are stored int the "node" linked list, and the document ids are stored int he "list" linked list */
 void inverted_index(char *str)
 {
 char *str1,line[300];
FILE *file7=fopen(str,"r");
 int x=2; 
if ( file7 != NULL )
 {
 while ( fgets ( line, sizeof line, file7 ) != NULL)
       {
   str1 = strtok(line, " \n");
   while(1)
   {
    if(str1 != NULL)
    {
     x=check(str1);  
   if(x==1)
     {
      append(str1);
      append_list(str);
     }
     else if(x==0)   
   { 
       append_list(str);
      } 
   }
    else  
  { 
    break;   
 }
    str1 = strtok(NULL, " \n");
   }
        }
       fclose (file7);
 }
 }  /*The stored linked lists are written to a file*/ 
void write_index() 
{
         struct list *temp=NULL;
  FILE *file8=fopen("index.txt","a");
  r=q;
  if(r==NULL) 
 {
   printf("\nEmpty Link List.Can't Display The Data");
   getch();
  }
  while(r!=NULL)
  {
   fprintf(file8," \n %s \t\t",r->word);
   for(temp=r->nolink;temp!=NULL;temp=temp->nolink)
   {
    fprintf(file8," \t %d",temp->num);
   }
   r=r->link;
  }
fclose(file8);
 }  /* The main module the only input asked here is the number of documents you have as input ,and the documents should be actually present we have used 3 due to computational and time limits and the sourcefile shoul always be named sfile%d.txt where %d should be some number in order starting from 1*/ 
void main()
 {
 int n,i;
 char str_s[50]={0},str_r[50]={0},str_e[50]={0};
 char *str1,*str2,*str3; 
clrscr();
 printf("Enter the no of files to be indexed");
 scanf("%d",&n);
 /*strcpy(str1,"rfile1.txt");
 extract(str1,str2,str3,6,1);
 puts(str3);
 printf("%s",str2);
 for(i=0;i<n;i++) 
sprintf(str_s[i],"sfile%d.txt",i+1);
 for(i=0;i<n;i++) 
sprintf(str_r[i],"rfile%d.txt",i+1);
 for(i=0;i<n;i++) 
sprintf(str_e[i],"efile%d.txt",i+1);
 for(i=0;i<n;i++) 
{
  printf("%s\t",str_s[i]);
  printf("%s\t",str_r[i]); 
 printf("%s\t",str_e[i]);
 }                       */
 for(i=0;i<n;i++) 
//Generating the file names rfile%d,efile%d 
{
  sprintf(str_s,"sfile%d.txt",i+1);
  sprintf(str_r,"rfile%d.txt",i+1);  
printf("\n%s\t%s",str_s,str_r);
  refine(str_s,str_r);
 }
 printf("\n");
 for(i=0;i<n;i++) 
{
  sprintf(str_r,"rfile%d.txt",i+1);
  sprintf(str_e,"efile%d.txt",i+1); 
 printf("\n%s\t%s\t",str_r,str_e);
  stop_ele(str_r,str_e);
 }
 destroy();
 //printf("\n"); 
for(i=0;i<n;i++) 
{
  sprintf(str_e,"efile%d.txt",i+1);  
printf("%s\t",str_e);
inverted_index(str_e);
 }
 write_index(); 
/*destroy(); 
display();
*/ getch();
 }